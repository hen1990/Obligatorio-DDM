import React from "react";
import RootStack from "./src/routes/RootStack"

const App = () => {
    return <RootStack />
}

export default App